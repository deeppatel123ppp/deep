var express = require("express")
var app = express()

student = {
    "name": "XYZ",
    "age":15
}

app.get("/j1", (req, res) => {
    res.send(student)
})

app.get("/j2", (req, res) => res.json(student))

app.get("/j3", (req, res) => {
    res.write(JSON.stringify(student))
    res.send()
})

app.listen(5007)