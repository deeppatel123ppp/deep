var express = require("express")
var app = express()

app.get("/", (req, res) => {
    res.type("text/html")
    res.write("<h3>Hello B4 Studensts</h3>")
    res.send()
})

app.get("/about", (req, res) => {
    res.write("<h3>HExpress JS</h3>")
    res.send()
})

app.listen(5007, () => {
    console.log("Server running on http://localhost:5007");
})