var path = require("path")
var express = require("express")
var app = express()

app.use(express.urlencoded())

var hp = path.join(__dirname, "../html")
var cp = path.join(__dirname, "../css")
var ip = path.join(__dirname, "../images")

app.use(express.static(cp))
app.use(express.static(ip))
app.use(express.static(hp, { index: "my.html" }))

app.post("/data", (req, res) => {
    res.type("text/html")
    res.write(`<h2>Welcome ${req.body.unm}</h2>
        <h4> Your message is : ${req.body.msg}</h4>`)
    var m = ((req.body.msg)).split(".")
    console.log(m);
    
    for (i in m) {
        res.write(m[i]+"<br>")
    }
    res.end()
})


app.listen(5007, () => {
    console.log("Server running on http://localhost:5007");
})
