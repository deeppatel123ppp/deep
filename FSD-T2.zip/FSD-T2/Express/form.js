var path = require("path")
var express = require("express")
var app = express()

app.use(express.urlencoded())

app.use(express.static(__dirname,{ index: "my.html" }))

app.get("/result", (req, res) => {
    var n = req.query.num

    if (req.query.opt === "cube") {
        res.write(`Cube is : ${n*n*n}`)
    } else if (req.query.opt === "square") {
        res.write(`Square is : ${n*n}`)
    } else {
        res.write(`Select Valid Option`)  
    }
    res.end()
})

app.listen(5007, () => {
    console.log("Server running on http://localhost:7001");
})