var express = require("express")
var app = express()

var entrylog = (req, res, next) => {
    console.log("Student Entered");
    next()
}

var checkId = (req, res, next) => {
    var hashId = true
    if (hashId) {
        req.name = "deep"
        console.log("Verified student");
        next()
    } else {
        console.log("Not Verified");
        res.send("No ID available")
    }
}

app.get("/", (req, res) => {
    res.send(`<a href=http://localhost:5001/student>Click Here</a>`)
})

app.use("/student", entrylog, checkId)
app.get("/student", (req, res) => {
    res.send(`Welcome ${req.name}`)
})

app.listen(5001, () => {
    console.log("Server running on http://localhost:5001");
})