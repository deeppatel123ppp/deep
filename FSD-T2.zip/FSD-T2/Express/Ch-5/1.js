var express = require("express")
var app = express()

// app.use(express.static(__dirname))
app.use(express.static("frontend",{index:'1.html'}))

app.listen(3001, () => {
    console.log("Server running on http://localhost:3001");
})