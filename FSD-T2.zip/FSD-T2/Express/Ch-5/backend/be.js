var express = require("express")
var path = require("path")
var app = express()

// app.use(express.static(__dirname))

// app.use(express.static("frontend",{index:'1.html'}))

// var sp = path.join(__dirname, "../")
// app.use(express.static(sp))

var sp = path.join(__dirname, "../frontend")
// app.use(express.static(sp,{index:'1.html'}))
app.use(express.static(sp)) // this will apply css

app.get("/", (req, res) => {
    res.sendFile(sp+"/1.html") //css will not apply
})

app.listen(3001, () => {
    console.log("Server running on http://localhost:3001");
})