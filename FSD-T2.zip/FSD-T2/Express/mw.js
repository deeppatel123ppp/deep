var express = require("express")
var app = express()

app.use(express.urlencoded())

app.get("/", (req, res) => {
    res.send(`Click Here to <a href=http://localhost:7001/login>Login</a>`)
})

app.get("/login", (req, res) => {
    res.send(`
        <form action="/data" method="post">
            <input type="text" name="unm">
            <input type="password" name="pass">
            <input type="password" name="cpass">
            <input type="submit">
        </form>    
        `)
})

var checkpass = (req, res, next) => {
    if (req.body.pass === req.body.cpass) {
        console.log("password matched");
        next()
    } else {
        res.send("Not valid password")
    }
}

app.post("/data", checkpass, (req, res) => {
    res.send(`<h1>Welcome ${req.body.unm}</h1>`)
})

app.listen(7001, () => {
    console.log("Server running on http://localhost:7001");
})