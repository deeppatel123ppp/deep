var cp = require("cookie-parser")
var express = require("express")
var app = express()

app.use(cp())

app.get("/", (req, res) => {
    res.cookie("fname", "deep")
    res.cookie("lname", "patel")
    res.cookie("subject", "FSD", { maxAge: 10000 })
    
    res.clearCookie("lname")
    res.send(req.cookies)
})

app.listen(7001, () => {
    console.log("Server running on http://localhost:7001");
})