var express = require("express")
var app = express()

let data = [
    {
        "name": "x",
        "age":20
    },
    {
        "name": "y",
        "age":28
    },
    {
        "name": "z",
        "age":18
    }
]

app.get("/", (req, res) => res.json(data))

app.get("/sort", (req, res) => {
    sort_obj = data.sort((a, b) => b.age - a.age)
    res.type("text/html")

    res.write(`<table border=1>
                    <tr>
                        <th>Name</th>
                        <th>Age</th>
                    </tr>`)
    for (s of sort_obj) {
        res.write(`<tr>
                      <td>${s.name}</td>
                      <td>${s.age}</td>
                    </tr>`)
    }
    res.write("</table>")
    res.send()
})

app.listen(5001)